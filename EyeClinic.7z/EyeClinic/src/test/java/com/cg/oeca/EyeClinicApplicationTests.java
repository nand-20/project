package com.cg.oeca;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EyeClinicApplicationTests {

}
